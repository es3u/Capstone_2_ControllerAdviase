package com.example.capstone2.Controller;

import com.example.capstone2.Model.Bidding;
import com.example.capstone2.Service.BiddingServicce;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.Errors;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/bidding")
@RequiredArgsConstructor
public class BiddingController {
    private final BiddingServicce biddingServicce;
    @GetMapping("/getAllBidding")
    public ResponseEntity getAllBidding(){
        return ResponseEntity.ok(biddingServicce.getAllBidding());
    }
    @GetMapping("/getBiddingById/{biddingId}")
    public ResponseEntity getBiddingById(@PathVariable Integer biddingId){
        return ResponseEntity.ok(biddingServicce.getBiddingById(biddingId));
    }
    @PostMapping("/addBidding/{id}")
    public ResponseEntity addBidding( @RequestBody@Valid Bidding bidding ){
        biddingServicce.addBidding(bidding);
        return ResponseEntity.ok().body("Added bidding successfully");
    }
    @GetMapping("/highestBid/{bidId}")
    public ResponseEntity highestBid(@PathVariable Integer bidId){
       List list =  biddingServicce.allBiddin(bidId);
        return ResponseEntity.ok().body(list);
    }
    @PutMapping("/buy/{bidId}")
    public ResponseEntity buy(@PathVariable Integer bidId){
        biddingServicce.buy(bidId);
        return ResponseEntity.ok().body("Buy successfully");
    }

    @GetMapping("/getHighestBid/{bidId}")
    public ResponseEntity getHighestBid(@PathVariable Integer bidId){
        List list =  biddingServicce.allBiddin(bidId);
        return ResponseEntity.ok().body(list);
    }








}
