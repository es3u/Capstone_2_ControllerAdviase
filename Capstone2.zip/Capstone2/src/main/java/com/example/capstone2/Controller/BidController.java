package com.example.capstone2.Controller;

import com.example.capstone2.Model.Bid;
import com.example.capstone2.Service.BidService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1/bid")
@RequiredArgsConstructor
public class BidController {
    private final BidService bidService;

    @GetMapping("/getAll")
    public ResponseEntity getAllBids() {
        return ResponseEntity.ok(bidService.getAllBids());
    }
    @PostMapping("/addBid")
    public ResponseEntity addBid(@RequestBody@Valid Bid bid) {
        bidService.addBid(bid);
        return ResponseEntity.ok().body("add bid successfully");
    }
}
