package com.example.capstone2.Service;

import com.example.capstone2.ApiResponse.ApiExcption;
import com.example.capstone2.Model.*;
import com.example.capstone2.Repository.*;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.Comparator;
import java.util.List;

@Service
@RequiredArgsConstructor
public class BiddingServicce {
    private final BiddingRepository biddingRepository;
    private final BidRepository bidRepository;
    private final UserRepository userRepository;
    private final CarRepository carRepository;

    public List<Bidding> getAllBidding(){
        return biddingRepository.findAll();
    }


    public Bidding getBiddingById(Integer id){
        Bidding bidding= biddingRepository.findBiddingById(id);
        if(bidding==null){
            throw new ApiExcption("Bidding not found");
        }
        return bidding;
    }


    public void addBidding(Bidding bidding){
        Bid bid = bidRepository.findBidById(bidding.getBidId());
        if(!bidding.getBidId().equals(bid.getId())){
            throw new ApiExcption("bid is not exists");
        }
        User bidder = userRepository.findUserById(bidding.getBidder());
        if (!bidding.getBidder().equals(bidder.getId())) {
            throw new ApiExcption("bidder is not exists");
        }

        biddingRepository.save(bidding);
    }

    public List allBiddin(Integer bidId){
        List bidding = biddingRepository.findBiddingByBidId(bidId);

        if(bidding==null){
            throw new ApiExcption("bidding not found");
        }
        return bidding;
    }


    public void buy(Integer biddingId){
        Bidding bidding = getHighestBid(biddingId);// highestBid
        Bid bid = bidRepository.findBidById(bidding.getBidId());
        if(bidding==null){
            throw new ApiExcption("bidding not found");
        }
        if (bid.isClosed() == true) {
            User bidder = userRepository.findUserById(bidding.getBidder());
            User seller = userRepository.findUserById(bid.getSellerId());
            Car car = carRepository.findCarById(bid.getCarId());

            bidder.setBalance(bidder.getBalance() - bidding.getPrice());
            seller.setBalance(seller.getBalance() + bidding.getPrice());

            car.setUserId(bidder.getId());

            bid.setEndDate(LocalDateTime.now());

            carRepository.save(car);
            userRepository.save(seller);
            userRepository.save(bidder);
            biddingRepository.save(bidding);
            bidRepository.save(bid);

        }else throw new ApiExcption("The operation was not completed");

    }

    public Bidding getHighestBid(Integer bidId) {

        List<Bidding> bids = biddingRepository.findBiddingByBidId(bidId);

        if (bids != null && !bids.isEmpty()) {
            return bids.stream()
                    .max(Comparator.comparing(Bidding::getPrice))
                    .orElse(null);
        }
        return null;
    }

















}
