package com.example.capstone2.ApiResponse;

public class ApiExcption extends RuntimeException {

    public ApiExcption(String message) {
        super(message);
    }
}
