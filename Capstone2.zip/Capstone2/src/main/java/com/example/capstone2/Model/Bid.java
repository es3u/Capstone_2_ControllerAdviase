package com.example.capstone2.Model;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Bid {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id ;

    @NotNull(message = "user id can not be Empty")
    @Column(columnDefinition = "int not null")
    private Integer sellerId;

    @NotEmpty(message = "description id can not be Empty")
    @Column(columnDefinition = "varchar(20) not null")
    private String sellerName;

    @NotNull(message = "car id can not be Empty")
    @Column(columnDefinition = "int not null")
    private Integer carId ;

    @NotEmpty(message = "description id can not be Empty")
    @Column(columnDefinition = "varchar(100) not null")
    private String description;

    @NotNull
    @Column(columnDefinition = "datetime not null")
    private LocalDateTime bidDate = LocalDateTime.now();

    @NotNull(message = "end date can be not null")
    @Column(columnDefinition = "datetime not null")
    private LocalDateTime endDate = LocalDateTime.now() ;



    @NotNull(message = "isClosed can not be null")
    @Column(columnDefinition = "boolean not null")
    private boolean isClosed = false ;
    //هذا المتغير الميثود حقتها عشان تتم المبايعة في كلاس الادمن سيرفس اذا تمت المبايعة علشان يغلق المزاد


    @NotNull(message = "isClosed can not be null")
    public boolean isClosed() {
        return isClosed;
    }

    public void setClosed(@NotNull(message = "isClosed can not be null") boolean closed) {
        isClosed = closed;
    }
}
