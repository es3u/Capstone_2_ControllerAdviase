package com.example.capstone2.Service;

import com.example.capstone2.ApiResponse.ApiExcption;
import com.example.capstone2.Model.Bid;
import com.example.capstone2.Model.Car;
import com.example.capstone2.Model.User;
import com.example.capstone2.Repository.AdminRepository;
import com.example.capstone2.Repository.BidRepository;
import com.example.capstone2.Repository.CarRepository;
import com.example.capstone2.Repository.UserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class BidService {

    private final BidRepository bidRepository;
    private final AdminRepository adminRepository;
    private final UserRepository userRepository;
    private final CarRepository carRepository;

    public List<Bid> getAllBids() {
        return bidRepository.findAll();
    }

    public void addBid(Bid bid) {
        User seller = userRepository.findUserById(bid.getSellerId());
        if (!bid.getSellerId().equals(seller.getId())) {
            throw new ApiExcption("Seller is not found");
        }
        Car car = carRepository.findCarByIdAndUserId(bid.getSellerId() ,bid.getCarId());
        if (!bid.getCarId().equals(car.getId())) {
            throw new ApiExcption("This user does not own the car.");
        }
        bidRepository.save(bid);
    }

    public void updateBid(Integer id ,Bid bid) {
        Bid b = bidRepository.findBidById(id);
        if (bid == null) {
            throw new ApiExcption("Bid not found");
        }
        b.setSellerName(bid.getSellerName());
        b.setSellerId(bid.getSellerId());
        b.setCarId(bid.getCarId());
        bidRepository.save(b);
    }
    public void deleteBid(Integer id) {
        Bid bid = bidRepository.findBidById(id);
        if (bid == null) {
            throw new ApiExcption("Bid not found");
        }
        bidRepository.delete(bid);
    }



}
